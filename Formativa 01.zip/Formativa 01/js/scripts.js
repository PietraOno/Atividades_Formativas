//atividade 1
function validarDados() {
    let data = frmRegistro.inData.value;
    let cliente = frmRegistro.inCli.value;
    let telefone = frmRegistro.inFone.value;
    let email = frmRegistro.inMail.value;
    let produto = frmRegistro.inProd.value;
    let quantidade = frmRegistro.inQtd.value;
    let valor = frmRegistro.inVal.value;
    document.getElementById("msg-erro").innerHTML = "";

    if (data.trim() == '') {
        document.getElementById("msg-erro").innerHTML = "Você esqueceu da data!";
        frmRegistro.inData.focus();
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (cliente.trim() == '') {
        document.getElementById("msg-erro").innerHTML = "Você esqueceu do seu nome!";
        frmRegistro.inCli.focus();
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (telefone.trim() == '') {
        document.getElementById("msg-erro").innerHTML = "Você esqueceu do telefone!";
        frmRegistro.inCli.focus();
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (email.trim() == '') {
        document.getElementById("msg-erro").innerHTML = "Você esqueceu do email!";
        frmRegistro.inCli.focus();
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (produto.trim() == '') {
        document.getElementById("msg-erro").innerHTML = "Qual o nome do produto mesmo?";
        frmRegistro.inCli.focus();
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (quantidade.trim() == '') {
        document.getElementById("msg-erro").innerHTML = "Quantos produtos você comprou?";
        frmRegistro.inCli.focus();
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (valor.trim() == '') {
        document.getElementById("msg-erro").innerHTML = "Qual era o valor do produto?";
        frmRegistro.inCli.focus();
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (cliente.length < 5) {
        document.getElementById("msg-erro").innerHTML = "Nome muito curto!";
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (telefone.length < 5) {
        document.getElementById("msg-erro").innerHTML = "Certeza que o número de telefone está certo?";
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (email.length < 5) {
        document.getElementById("msg-erro").innerHTML = "Certeza que seu e-mail está certo?";
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (produto.length < 5) {
        document.getElementById("msg-erro").innerHTML = "Certeza que o nome do produto está certo?";
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (quantidade < 0) {
        document.getElementById("msg-erro").innerHTML = "A quantidade não pode ser negativa!";
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    if (valor < 0) {
        document.getElementById("msg-erro").innerHTML = "O valor não pode ser negativo!";
        document.getElementById("msg-erro").style.display = "block";
        document.getElementById("msg-sucesso").style.display = "none";
        return false;
    }

    document.getElementById("msg-erro").style.display = "none";
    document.getElementById("msg-sucesso").innerHTML = "Formulário enviado com sucesso!";
    document.getElementById("msg-sucesso").style.display = "block";
}

//atividade 2
function criarImagens() {
    let qtdImagens = document.getElementById('inQtdImg').value;
    let imagensHtml = '';
    for (let i = 0; i < qtdImagens; i++) {
        imagensHtml += '<img src="img/gato.jpg" alt="Imagem de um gato preto deitado olhando para você com os olhos dilatados" class="imagens">';
    }
    document.getElementById('canvas').innerHTML = imagensHtml;
}

//atividade 3
function alterarLamp() {
    let imagem = document.getElementById('lampada');
    let caminho = imagem.src;
    let arquivo = caminho.substring(caminho.lastIndexOf('/') + 1);

    if (arquivo == 'acesa.jpg' || arquivo == '')
        imagem.src = 'img/apagada.jpg';
    else
        imagem.src = 'img/acesa.jpg';
}

//atividade 4
document.getElementById("btnEnviar").addEventListener("click", function () {

    var valorPedido = parseFloat(document.getElementById("inValorPedido").value);

    if (valorPedido <= 0) {
        alert("O valor do pedido deve ser maior que zero!");
        return;
    }

    var desconto1 = 0.005;
    var desconto2 = 0.008;
    var desconto3 = 0.01;
    var desconto4 = 0.015;

    var percentualDesconto, valorDesconto;
    if (valorPedido >= 2000) {
        percentualDesconto = desconto4;
    } else if (valorPedido >= 1500) {
        percentualDesconto = desconto3;
    } else if (valorPedido >= 1000) {
        percentualDesconto = desconto2;
    } else if (valorPedido >= 500) {
        percentualDesconto = desconto1;
    } else {
        percentualDesconto = 0;
    }
    valorDesconto = valorPedido * percentualDesconto;

    var valorFinal = valorPedido - valorDesconto;

    document.getElementById("inPercDesc").value = percentualDesconto * 100;
    document.getElementById("inValDesc").value = valorDesconto.toFixed(2);
    document.getElementById("inValFinal").value = valorFinal.toFixed(2);
});