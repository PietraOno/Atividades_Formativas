var dados_pizza = [
  ['Status', 'Total']
];

var dados_mapa = [
  ['País', 'Confirmados'],
  ['0', 0]
];

function exibirErro(mensagem) {
  let erro = document.getElementById('div-erro');
  erro.style.display = 'block';
  erro.innerHTML = '<b>Erro ao acessar a API:</b><br />' + mensagem;
}

async function carregarDados2() {
  let erro = document.getElementById('div-erro');
  erro.style.display = 'none';

  await fetch('https://covid19-brazil-api.now.sh/api/report/v1/countries')
    .then(response => response.json())
    .then(dados => prepararDados2(dados))
    .catch(e => exibirErro(e.mensagem));
}

// Mapa e Gráfico
function prepararDados2(dados) {

  dados_mapa = [['País', 'Confirmados']];
  dados_pizza = [['Status', 'Total']];

  let pais = 0;
  let confirmados = 0;
  let mortos = 0;
  let recuperados = 0;
  let total = 0;



  for (let i = 0; i < dados['data'].length; i++) {
    pais = dados['data'][i].country;
    confirmados = dados['data'][i].confirmed;
    dados_mapa.push([pais, confirmados]);

    mortos += dados['data'][i].deaths;
    recuperados += dados['data'][i].recovered;
    total += dados['data'][i].confirmed;
  }

  dados_pizza.push(['Confirmados', total]);
  dados_pizza.push(['Mortos', mortos]);
  dados_pizza.push(['Recuperados', recuperados]);

  desenharMapa();
  desenharGraficoDePizza();
}


// Mapa
google.charts.load('current', {
  'packages': ['geochart'],
});
google.charts.setOnLoadCallback(desenharMapa);

function desenharMapa() {
  var data = google.visualization.arrayToDataTable(dados_mapa);

  var options = {
    colorAxis: { colors: ['#bfc0c0', '#525d5d', '#313939'] }, //inclui os daltônicos
  };

  var chart = new google.visualization.GeoChart(document.getElementById('mapa'));

  chart.draw(data, options);
}


// Gráfico
google.charts.load('current', { 'packages': ['corechart'] });
google.charts.setOnLoadCallback(desenharGraficoDePizza);

function desenharGraficoDePizza() {

  var data = google.visualization.arrayToDataTable(dados_pizza);

  var options = {
    title: 'My Daily Activities',
    slices: {
      0: { color: '#808989' },
      1: { color: '#000' }
    }
  };

  var chart = new google.visualization.PieChart(document.getElementById('grafico'));

  chart.draw(data, options);
}

// Tabela
async function carregarDados() {
  const divErro = document.getElementById('div-erro');
  divErro.style.display = 'none';

  await fetch('https://covid19-brazil-api.now.sh/api/report/v1')
    .then(response => response.json())
    .then(dados => prepararDados(dados))
    .catch(e => exibirErro(e.message));
}


function exibirErro(mensagem) {
  const divErro = document.getElementById('div-erro');
  divErro.style.display = 'block';
  divErro.innerHTML = '<b>Erro ao acessar a API</b><br />' + mensagem;
}

function prepararDados(dados) {

  let linhas = document.getElementById('linhas');
  linhas.innerHTML = '';


  for (let i = 0; i < dados['data'].length; i++) {
    let auxLinha = '';

    if (i % 2 != 0)
      auxLinha = '<tr class="listra">';
    else
      auxLinha = '<tr>';

    auxLinha += '<td>' + dados['data'][i].uf + '</td>' +
      '<td>' + dados['data'][i].state + '</td>' +
      '<td>' + dados['data'][i].cases + '</td>' +
      '<td>' + dados['data'][i].deaths + '</td>' +
      '<td>' + dados['data'][i].suspects + '</td>' +
      '<td>' + dados['data'][i].refuses + '</td>' +
      '</tr>';

    linhas.innerHTML += auxLinha;
  }
}
